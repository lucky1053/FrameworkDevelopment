package automation.bootcamp.nop.pages;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import automation.bootcamp.nop.file.reader.PropertyReader;
import io.qameta.allure.Step;

public class LoginPage extends BasePage {

	private String url = PropertyReader.getProperty("baseUrl") + "/login";
	private Logger logger = LogManager.getLogger(LoginPage.class);

	// locators
	By email_textbox = By.id("Email");
	By password_textbox = By.id("Password");
	By login_button = By.cssSelector(".buttons [type=submit]");
	By logout_link = By.cssSelector(".ico-logout");
	By email_error = By.id("Email-error");

	public void launch() {
		logger.info("Launch Url: " + url);
		openPage(url);
	}

	@Step("Fill Username")
	public void fillUsername(String username) {
		logger.info("SignIn with Username: " + username);
		enterText(email_textbox, username);
	}

	@Step("Fill Password")
	public void fillPassword(String password) {
		enterText(password_textbox, password);
	}

	public void login() {
		click(login_button);
	}

	public String getEmailError() {
		String error = getText(email_error);
		return error;
	}

	public boolean isLoginSuccess() {
		return isElementDisplayed(logout_link);
	}

}
