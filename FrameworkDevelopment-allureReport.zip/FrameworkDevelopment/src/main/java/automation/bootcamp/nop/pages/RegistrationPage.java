package automation.bootcamp.nop.pages;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import automation.bootcamp.nop.file.reader.PropertyReader;

public class RegistrationPage extends BasePage {
	private Logger logger = LogManager.getLogger(RegistrationPage.class);
	private String url = PropertyReader.getProperty("baseUrl") + "/register";

	// page locators
	By gender_male_radioButton = By.id("gender-male");
	By gender_female_radioButton = By.id("gender-female");
	By registration_form = By.cssSelector(".page-body form");

	public void launch() {
		logger.info("Launch Url: " + url);
		openPage(url);
	}

	public boolean isRegistrationFormDisplayed() {
		return isElementDisplayed(registration_form);
	}

}