package automation.bootcamp.nop.utilities;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TestLog {

	private static Logger logger = LogManager.getLogger(TestLog.class);

	public static void main(String[] args) {
		//BasicConfigurator.configure();
		PropertyConfigurator.configure("src/main/resources/log.properties");
		
		logger.info("User naviagted to Home Page");
		logger.error("Unable to SignIn");
		logger.warn("Removing Data from the list");
		logger.debug("Debugging login module");
		
		
		
		// debug < info < warn < error
	}
}

//0 [main] INFO automation.bootcamp.nop.utilities.TestLog  - User naviagted to Home Page
//10 [main] ERROR automation.bootcamp.nop.utilities.TestLog  - Unable to SignIn
//10 [main] WARN automation.bootcamp.nop.utilities.TestLog  - Removing Data from the list
//10 [main] DEBUG automation.bootcamp.nop.utilities.TestLog  - Debugging login module
