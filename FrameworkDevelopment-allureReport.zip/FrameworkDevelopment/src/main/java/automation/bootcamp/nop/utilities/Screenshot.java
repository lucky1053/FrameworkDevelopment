package automation.bootcamp.nop.utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import automation.bootcamp.nop.drivermanager.DriverFactory;

public class Screenshot {

	public static String capture(String testcaseName) {
		File screenshot = ((TakesScreenshot) DriverFactory.getCurrentDriver()).getScreenshotAs(OutputType.FILE);
		String filePath = "./output/" + testcaseName + ".png";
		try {
			FileUtils.copyFile(screenshot, new File(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return filePath;
	}
}
