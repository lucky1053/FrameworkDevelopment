package automation.bootcamp.nop.pageflows;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import automation.bootcamp.nop.bo.LoginBo;
import automation.bootcamp.nop.pages.LoginPage;
import io.qameta.allure.Step;

public class LoginFlow {

	private static Logger logger = LogManager.getLogger(LoginFlow.class);

	@Step("Login to Application")
	public static void performLogin(LoginBo loginBo) {
		LoginPage login = new LoginPage();
		login.launch();
		login.fillUsername(loginBo.getUsername());
		login.fillPassword(loginBo.getPassword());
		login.login();
	}
}
