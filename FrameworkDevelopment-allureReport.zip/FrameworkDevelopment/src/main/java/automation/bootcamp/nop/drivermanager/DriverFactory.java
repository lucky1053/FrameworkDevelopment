package automation.bootcamp.nop.drivermanager;

import org.openqa.selenium.WebDriver;

import automation.bootcamp.nop.drivermanager.types.ChromeManager;
import automation.bootcamp.nop.drivermanager.types.FirefoxManager;
import automation.bootcamp.nop.file.reader.PropertyReader;

public class DriverFactory {
	
	// central storage
	private static ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<WebDriver>();

	public static WebDriver getDriver() {

		WebDriver driver = null;

		String browserName = PropertyReader.getProperty("browser");

		switch (BrowserType.valueOf(browserName.toUpperCase())) {
		case CHROME:
			driver = new ChromeManager().getDriver();
			break;
		case FIREFOX:
			driver = new FirefoxManager().getDriver();
			break;

		default:
			System.out.println("Unsupported browser");
		}
		
		// set driver
		driverThreadLocal.set(driver);

		return driver;
	}
	
	public static WebDriver getCurrentDriver() {
		return driverThreadLocal.get();
	}
	
	public static void removeDriver() {
		driverThreadLocal.remove();
	}
}
