package automation.bootcamp.nop.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import automation.bootcamp.nop.pages.RegistrationPage;

public class RegistrationPageTest extends BaseTest {

	@Test()
	public void performSignup() {
		RegistrationPage registrationPage = new RegistrationPage();
		registrationPage.launch();

		Assert.assertTrue(registrationPage.isRegistrationFormDisplayed(), "Registartion Form not displayed");
	}
}
