package automation.bootcamp.nop.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import automation.bootcamp.nop.bo.LoginBo;
import automation.bootcamp.nop.dataprovider.LoginDataProvider;
import automation.bootcamp.nop.pageflows.LoginFlow;
import automation.bootcamp.nop.pages.LoginPage;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Issue;
import io.qameta.allure.Link;
import io.qameta.allure.Owner;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;

public class LoginPageTest extends BaseTest {

	@Test(dataProvider = "validData", dataProviderClass = LoginDataProvider.class)
	@Epic("Login Module")
	@Feature("Validate Login Functionality")
	@Story("Test Login Component")	
	@Description("Login with Valid Credentials")
	@Severity(SeverityLevel.BLOCKER)
	public void login(LoginBo login) {
		LoginPage loginPage = new LoginPage();

		LoginFlow.performLogin(login);
		Assert.assertTrue(loginPage.isLoginSuccess(), "Unable to login to the application");
	}

	@Test(dataProvider = "invalidData", dataProviderClass = LoginDataProvider.class)
	@Epic("Login Module")
	@Feature("Validate Login Functionality")
	@Story("Test Login Component")	
	@Description("Login with invalid Credentials")
	@Severity(SeverityLevel.MINOR)
	@Issue("Issue-1")
	@Link(name="Jira-123")
	@Owner("User1")
	@TmsLink("JIra-456")
	public void forgotPassword(LoginBo login) {
		LoginPage loginPage = new LoginPage();

		LoginFlow.performLogin(login);

		String errorMessage = loginPage.getEmailError();
		Assert.assertEquals(errorMessage, "Wrong email");

	}
}
