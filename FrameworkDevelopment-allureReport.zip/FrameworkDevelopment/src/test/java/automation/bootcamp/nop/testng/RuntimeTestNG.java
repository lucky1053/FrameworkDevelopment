package automation.bootcamp.nop.testng;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.ResourcesScanner;
import org.reflections.scanners.SubTypesScanner;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.reflections.util.FilterBuilder;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlSuite.ParallelMode;
import org.testng.xml.XmlTest;

import automation.bootcamp.nop.bo.TestcaseBO;
import automation.bootcamp.nop.file.reader.ExcelReader;
import automation.bootcamp.nop.tests.BaseTest;

public class RuntimeTestNG {

	private String testcasePackagePath = "automation.bootcamp.nop.tests";

	public TestNG create(List<TestcaseBO> testcaseList) {
		TestNG testng = new TestNG();

		// list of suite
		List<XmlSuite> suiteList = new ArrayList<XmlSuite>();

		// Suite Object
		XmlSuite suite = new XmlSuite();
		suite.setName("Runtime Suite");
		suite.setThreadCount(2);
		suite.setParallel(ParallelMode.METHODS);

		// listeners
		List<String> listeners = new ArrayList<String>();
		listeners.add("automation.bootcamp.nop.listeners.CustomListener");
		suite.setListeners(listeners);

		// List of Test
		List<XmlTest> testList = new ArrayList<XmlTest>();

		// test object
		XmlTest test = new XmlTest(suite);
		test.setName("Test Object");

		// class list
		List<XmlClass> classList = new ArrayList<XmlClass>();

		// get test class from reflection
		Reflections reflections = getClasses();
		Set<Class<? extends BaseTest>> allClasses = reflections.getSubTypesOf(BaseTest.class);

		for (Class c : allClasses) {

			// xml class object
			XmlClass cls = new XmlClass(c);

			Method[] allMethods = c.getDeclaredMethods();

			// list of methods
			List<XmlInclude> methodList = new ArrayList<XmlInclude>();

			for (Method m : allMethods) {
				String methodName = m.getName();

				for (TestcaseBO bo : testcaseList) {
					if (methodName.equals(bo.getTestcaseName())) {
						methodList.add(new XmlInclude(methodName));
					}
				}

			}

			// add method to the class
			cls.setIncludedMethods(methodList);

			// add class to the list
			classList.add(cls);
		}

		// add class list to test
		test.setXmlClasses(classList);

		// add test to test list
		testList.add(test);

		// add test list to suite
		suite.setTests(testList);

		// add suite to suite list
		suiteList.add(suite);

		// print xml
		System.out.println(suite.toXml());

		testng.setXmlSuites(suiteList);

		return testng;
	}

	public Reflections getClasses() {
		final ConfigurationBuilder config = new ConfigurationBuilder()
				.setScanners(new ResourcesScanner(), new SubTypesScanner(false))
				.setUrls(ClasspathHelper.forPackage(testcasePackagePath))
				.filterInputsBy(new FilterBuilder().includePackage(testcasePackagePath));

		final Reflections reflect = new Reflections(config);

		return reflect;

	}

	public static void main(String[] args) {
		System.out.println("Running");

		ExcelReader excel = new ExcelReader();
		List<TestcaseBO> testcaseList = excel.read();

		RuntimeTestNG test = new RuntimeTestNG();
		TestNG testng = test.create(testcaseList);
		testng.run();
	}
}
