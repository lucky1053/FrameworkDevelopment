package automation.bootcamp.nop.dataprovider;

import org.testng.annotations.DataProvider;

import com.github.javafaker.Faker;

import automation.bootcamp.nop.bo.LoginBo;

public class LoginDataProvider {

	@DataProvider(name = "invalidData")
	public Object[][] getInvalidData() {
		int max_limit = 3;
		Faker faker = new Faker();
		Object[][] object = new Object[max_limit][1];
		for (int i = 0; i < max_limit; i++) {
			LoginBo login = new LoginBo();
			login.setUsername(faker.name().username());
			login.setPassword(faker.internet().password());
			object[i][0] = login;
		}
		return object;
	}

	@DataProvider(name = "validData")
	public Object[][] getValidData() {
		Object[][] object = new Object[1][1];
		
		LoginBo login = new LoginBo();
		login.setUsername("test@gmail.com");
		login.setPassword("test@123");

		object[0][0] = login;
		return object;
	}
}
