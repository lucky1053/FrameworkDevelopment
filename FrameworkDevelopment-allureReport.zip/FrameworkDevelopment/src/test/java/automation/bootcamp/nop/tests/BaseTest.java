package automation.bootcamp.nop.tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import automation.bootcamp.nop.drivermanager.DriverFactory;
import automation.bootcamp.nop.file.reader.PropertyReader;

public class BaseTest {

	@BeforeSuite
	public void loadData() {
		PropertyReader pr = new PropertyReader();
	}
	
	@BeforeMethod
	public void launchBrowser() {
		DriverFactory.getDriver();
	}

	@AfterMethod
	public void closeBrowser() {
		DriverFactory.getCurrentDriver().quit();
		DriverFactory.removeDriver();
	}
}
