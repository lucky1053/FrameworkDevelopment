package automation.bootcamp.nop;

import java.util.List;

import org.apache.log4j.PropertyConfigurator;
import org.testng.TestNG;

import automation.bootcamp.nop.bo.TestcaseBO;
import automation.bootcamp.nop.file.reader.ExcelReader;
import automation.bootcamp.nop.file.reader.PropertyReader;
import automation.bootcamp.nop.testng.RuntimeTestNG;

public class StartUp {
	public static void main(String[] args) {
		// configure log
		PropertyConfigurator.configure("src/main/resources/log.properties");

		// Load Properties file
		new PropertyReader();

		// load testcase Excel
		ExcelReader excel = new ExcelReader();
		List<TestcaseBO> testcaseList = excel.read();

		// Generate TestNG
		RuntimeTestNG test = new RuntimeTestNG();
		TestNG testng = test.create(testcaseList);

		// Initiate Execution
		testng.run();
	}
}
