package com.bootcamp.FrameworkDevelopment;

import org.testng.annotations.Test;

public class mnb {
	
@Test
	public void as(){
		System.out.println("hi");
	}
}
